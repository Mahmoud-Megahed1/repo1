import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { SupportChatController } from './support-chat.controller';
import { SupportChatService } from './support-chat.service';
import { ChatConversation, ChatConversationSchema } from './schemas/chat.schema';
import { UserModule } from '../user/user.module';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: ChatConversation.name, schema: ChatConversationSchema },
        ]),
        UserModule,
    ],
    controllers: [SupportChatController],
    providers: [SupportChatService],
    exports: [SupportChatService],
})
export class SupportChatModule { }
