export enum Role {
  USER = 'user',
  ADMIN = 'admin',
}

export enum AdminRole {
  SUPER = 'super',
  MANAGER = 'manager',
  OPERATOR = 'operator',
  VIEW = 'view',
}
