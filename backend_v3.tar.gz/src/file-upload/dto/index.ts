export * from './lesson-upload.dto';
export * from './delete-obj.dto';
export * from './get-content-aws';
export * from './speak-compare-transcripts.dto'
