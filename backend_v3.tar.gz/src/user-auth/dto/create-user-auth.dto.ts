export class CreateUserAuthDto {}
