export class UserAuth {}
