
export const EmailMessages = {
    
    SuspensionReasonMessage  : 'Account suspended due to inactivity (65+ days)' ,
    AccountSuspendedMessage  : 'Your account has been suspended. Please contact support for assistance.' ,
    weMissYouMessage : "We noticed you haven't logged into your Englishom account for a while. We miss you! Come back and continue your language learning journey with us.",
}