import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { SupportChatController } from './support-chat.controller';
import { SupportChatService } from './support-chat.service';
import { ChatConversation, ChatConversationSchema } from './schemas/chat.schema';
import { User, UserSchema } from '../user/models/user.schema';

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: ChatConversation.name, schema: ChatConversationSchema },
            { name: User.name, schema: UserSchema },
        ]),
    ],
    controllers: [SupportChatController],
    providers: [SupportChatService],
    exports: [SupportChatService],
})
export class SupportChatModule { }
