import axiosClient from '@lib/axios-client';
import { toFormData, type AxiosRequestConfig } from 'axios';
import type { LessonParams } from './types';
import type { LevelId } from '@shared/types/entities';

export const getLesson = <T = unknown>(
  params: LessonParams,
  config?: Omit<AxiosRequestConfig, 'params'>
) => {
  return axiosClient.get<{
    data: T[];
  }>('/files', { params, ...config });
};

export const uploadAudio = (
  data: {
    file: File;
  } & LessonParams
) => {
  return axiosClient.post<{ url: string }>(
    '/files/user-audio',
    toFormData(data)
  );
};

export const getTodayAudio = ({
  day,
  level_name,
}: Omit<LessonParams, 'lesson_name'>) => {
  return axiosClient.get<{ url: string }>(
    `/files/user-audio/${level_name}/${day}`
  );
};

export function markDayAsCompleted({
  levelName,
  day,
}: {
  levelName: LevelId;
  day: number | string;
}) {
  return axiosClient.post(`/users/complete-day`, {
    levelName,
    day: +day,
  });
}

export async function compareAudio(data: {
  audio: File;
  level_name: LevelId;
  sentenceText: string;
}) {
  return axiosClient.post<{
    similarityPercentage: number;
    correctSentence: string;
    userTranscript: string;
    isPassed: boolean;
    audioUrl?: string;
  }>('/user-results/speak/compare-transcript', toFormData(data));
}

export function combineLevelAudios(levelName: LevelId) {
  return axiosClient.post<{ url: string }>(`/files/user-audio/combine-level`, {
    levelName,
  });
}

export function getCombinedLevelAudio(levelName: LevelId) {
  return axiosClient.get<{ url: string }>(
    `/files/user-audio/combine-level/${levelName}`
  );
}

export const getSentenceAudios = ({
  levelName,
}: {
  levelName: LevelId;
}) => {
  return axiosClient.get<{ sentence: string; url: string }[]>(
    `/files/user-audio/sentences/${levelName}`
  );
};
