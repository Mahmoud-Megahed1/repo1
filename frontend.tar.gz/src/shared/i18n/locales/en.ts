import type { TranslationType } from '../translation.type';

export default {
  Landing: {
    header: {
      navigation: {
        features: 'Features',
        levels: 'Levels',
        reviews: 'Reviews',
        faq: 'FAQ',
        ourVision: 'Our Vision',
        about: 'About Us',
        contact: 'Contact Us',
      },
      cta: {
        login: 'Login',
      },
    },
    hero: {
      title: 'Master English with',
      subtitle: 'Interactive Learning Platform',
      description:
        'Transform your English skills with our comprehensive learning platform. Practice speaking, listening, reading, and writing through engaging daily lessons.',
      cta: 'Start Learning Now',
      watchDemo: 'Watch Demo',
    },
    features: {
      title: 'Why Choose Englishom?',
      subtitle: 'Everything you need to master English',
      items: {
        interactive: {
          title: 'Interactive Lessons',
          description:
            'Engage with dynamic content including audio and interactive exercises designed to keep you motivated.',
        },
        speaking: {
          title: 'Speaking Practice',
          description:
            'Improve your pronunciation with our advanced speech recognition technology and get instant feedback.',
        },
        progress: {
          title: 'Track Progress',
          description:
            'Monitor your learning journey with detailed analytics and celebrate your achievements along the way.',
        },
        levels: {
          title: 'Multiple Levels',
          description:
            'Choose from beginner to advanced levels with structured 50-day learning programs for each level.',
        },
        daily: {
          title: 'Daily Practice',
          description:
            'Build consistent learning habits with daily lessons, tests, and speaking exercises.',
        },
        certificate: {
          title: 'Certificates',
          description:
            'Earn certificates upon completing each level to showcase your English proficiency achievements.',
        },
      },
    },
    levels: {
      title: 'Choose Your Learning Path',
      subtitle: 'Learning pathways specially designed for each level',
      LEVEL_A1: {
        features: [
          'The First Step',
          'Speak to Start: We Are Waiting for Your Voice',
          'Tasks That Can Only Be Completed by Speaking',
          'Your Daily Routine in Your Own Voice',
          'Instant Analysis of Your Pronunciation Accuracy',
        ],
      },
      LEVEL_A2: {
        features: [
          'Direct Communication',
          'Describing Places and Daily Situations',
          'Past and Future',
          'Advanced Pronunciation Analysis',
          'Daily Life Scenarios',
        ],
      },
      LEVEL_B1: {
        features: [
          'Business English',
          'Academic writing',
          'Advanced speaking',
          'Native-like fluency',
        ],
      },
      LEVEL_B2: {
        features: [
          'Professional skills',
          'Advanced writing',
          'Complex discussions',
          'Cultural understanding',
        ],
      },
      LEVEL_C1: {
        features: [
          'Language mastery',
          'Academic writing',
          'Fluent speaking',
          'Critical analysis',
        ],
      },
      LEVEL_C2: {
        features: [
          'Complete fluency',
          'Specialized writing',
          'Advanced communication',
          'Intellectual leadership',
        ],
      },
    },
    testimonials: {
      title: 'What Our Students Say',
      subtitle: 'Join thousands of successful English learners',
      items: {
        sarah: {
          name: 'Sarah Ahmed',
          role: 'Marketing Professional',
          content:
            'Englishom transformed my career. The speaking practice feature helped me gain confidence in business meetings.',
        },
        mohammed: {
          name: 'Mohammed Ali',
          role: 'University Student',
          content:
            'The structured 50-day programs made learning systematic and enjoyable. I completed 3 levels in 6 months!',
        },
        fatima: {
          name: 'Fatima Hassan',
          role: 'Teacher',
          content:
            'As an English teacher, I recommend Englishom to all my students. The daily practice keeps them engaged.',
        },
      },
    },
    fqa: {
      title: 'Frequently Asked Questions',
      description:
        "Find answers to common questions about Englishome's learning approach and platform.",
      questions: [
        {
          question: 'How does the daily learning structure work?',
          answer:
            'Each day, you will complete a set of activities designed to build your skills progressively. This includes reading, listening, speaking, and writing exercises.',
        },
        {
          question: 'What levels are available?',
          answer:
            'We offer six levels from A1 (Beginner) to C2 (Proficient). Each level is designed to help you master the language step by step.',
        },
        {
          question: 'Can I track my progress?',
          answer:
            'Yes! You can monitor your daily progress, achievements, and areas needing improvement through our analytics dashboard.',
        },
        {
          question: 'Is there a mobile app?',
          answer:
            'Yes! Our platform is accessible on both desktop and mobile devices, allowing you to learn anytime, anywhere.',
        },
        {
          question: "What is the website's privacy policy?",
          answer:
            'We take your privacy seriously. Personal data is collected only when necessary and stored securely. We will not share your information with third parties without your consent.',
        },
      ],
    },
    cta: {
      title: 'Ready to Start Your English Journey?',
      subtitle:
        'Join thousands of learners who have improved their language skills and unlocked new opportunities.',
      description:
        'Start today with our all-in-one learning platform, and unleash your potential step by step with confidence.',
      primary: 'Start Learning Now',
      secondary: 'View Pricing',
    },
    contact: {
      title: 'Contact Us',
      subtitle:
        "We're here to help you on your English learning journey. Reach out to us via email or social media.",
      emailsSection: {
        title: 'Email Contact',
        description:
          'Get in touch with us directly via email for support and assistance.',
      },
      emails: {
        support: {
          type: 'Technical Support',
          description: 'For technical help and support',
        },
        info: {
          type: 'General Information',
          description: 'For general inquiries and information',
        },
        billing: {
          type: 'Billing & Payments',
          description: 'For billing and payment inquiries',
        },
        admin: {
          type: 'Administration & Complaints',
          description: 'For contacting administration and complaints',
        },
      },
      socialSection: {
        title: 'Social Media',
        description:
          'Follow us on social media for the latest news and updates.',
      },
      social: {
        facebook: 'Follow us for latest news and tips',
        instagram: 'Visual learning content',
        snapchat: 'Quick and fun content',
        telegram: 'Join our learning community',
        whatsapp: 'Quick and direct contact',
        tiktok: 'Short educational videos',
        twitter: 'Latest news and updates',
        youtube: 'Detailed video lessons',
      },
      additionalInfo: {
        title: 'Additional Information',
        responseTime:
          'We are committed to responding to your inquiries within 24 hours.',
        languages:
          'We speak Arabic and English to help with all your inquiries.',
        preferredEmail: 'For the fastest response, please contact us at:',
      },
    },
    stats: {
      students: {
        number: '10,000+',
        label: 'Active Students',
      },
      lessons: {
        number: '500+',
        label: 'Interactive Lessons',
      },
      success: {
        number: '95%',
        label: 'Success Rate',
      },
      countries: {
        number: '25+',
        label: 'Countries',
      },
    },
    about: {
      title: 'About Us',
      subtitle:
        'Learn about our story and vision in English language education',
      sections: {
        story: {
          title: 'Our Story',
          description:
            'Our idea began with a deep belief that speaking English is not a luxury, but a key to opening doors of opportunity in our connected world. We noticed that many learners struggle to overcome the fear barrier and start speaking fluently, even after years of studying grammar and vocabulary. From here, our vision was born to design a curriculum that breaks these barriers and focuses intensively on effective daily practice, transforming "I want to speak English" into "I speak English fluently".',
        },
        team: {
          title: 'Our Team',
          description:
            'Our team includes a group of linguistic experts, experienced teachers, and passionate developers, all committed to one mission: helping you speak fluently in the fastest and easiest ways. We combine the latest and simplest teaching methods, practical experience in language teaching, and genuine passion for empowering learners to communicate in English with ease.',
        },
        quality: {
          title: 'Our Commitment to Quality',
          description:
            'We are committed to delivering the highest levels of quality in every aspect of our platform. From designing research-based curriculum, to selecting high competence, and providing continuous technical support, we work hard to ensure that your learning journey with us is effective, enjoyable, and barrier-free. Quality is not just a slogan, but the cornerstone of everything we do.',
        },
        join: {
          title: 'Join Us',
          description:
            'Are you ready to break the language barrier and start speaking fluently? Join us today on your journey to mastering English. Discover the power of daily practice, and watch how your communication dreams become reality. Your English-speaking future starts here!',
        },
      },
    },
    ourVision: {
      title: 'Our Vision',
      subtitle:
        'Empowering individuals to break the barrier of fear and express themselves fluently and confidently through intensive and interactive learning.',
      sections: {
        vision: {
          title: 'Our Vision',
          description:
            "To be the world's leading platform for teaching English speaking, empowering individuals to break the barrier of fear and express themselves fluently and confidently, through an intensive and interactive learning methodology focused on daily practice.",
        },
        goal: {
          title: 'Our Goal',
          description:
            'To build confident speakers capable of communicating in English. We commit you to focused, enjoyable daily effort to reach an advanced level of fluency, where you will be able to speak about yourself and your background continuously for 15 minutes, all within the vocabulary you have learned and mastered.',
        },
        methodology: {
          title: 'How We Achieve This?',
          subtitle:
            ' Our unique methodology that divides your learning journey into clear levels.',
          description:
            'Our website relies on an intensive and meticulously structured methodology that divides your learning journey into clear levels, from Beginner (A1) to Advanced (C1), with each level carefully designed to ensure your progress:',
          ourStructureApproach: 'Our Structure & Approach',
          points: {
            wordsPerLevel: {
              title: '1000 Words Per Level',
              description:
                'Each level focuses on mastering 1000 essential words. You will learn these words with correct pronunciation, within contextual sentences, practice writing them, hear them repeatedly, and associate them with illustrative images to solidify their meaning.',
            },
            dailyWords: {
              title: '20 Words Daily',
              description:
                'To ensure continuity and effectiveness, you will learn 20 new words daily, meaning each level will be completed in 50 study days.',
            },
            pronunciation: {
              title: 'Daily Speaking Practice (25 seconds)',
              description:
                'Every day, you will record your voice for 25 seconds. You will find pre-written sentences about yourself (like your name, where you live, your interests), tailored to your current vocabulary level. This daily exercise will force you to practice effective pronunciation and repetition.',
            },
            speaking: {
              title: 'Building Continuous Speaking Ability',
              description:
                'Over these 50 days, these sentences and words will accumulate in your active memory. By the last day of each level, you will find yourself able to speak about yourself, give an overview, or present your biography for 15 consecutive minutes, using the 1000 words you have mastered.',
            },
            scenarios: {
              title: 'Inspiring Daily Scenarios',
              description:
                'Our website provides daily conversation scenarios of what you can say within the vocabulary range specified for your level, making it easy for you to apply what you learn directly in realistic dialogues.',
            },
          },
        },
        mission: {
          title: 'Our Mission & Values',
          description:
            'We believe that the key to fluency lies in continuous daily practice and conscious repetition. Our website not only provides you with knowledge but also imposes a daily, enjoyable challenge that makes you speak and progress steadily towards your bigger goal: unparalleled fluency.',
          missionTitle: 'Our Mission',
          missionDescription:
            'To empower every learner to achieve their full potential in speaking English, by building a bridge between linguistic knowledge and practical application, with a focus on self-confidence and fluency.',
          valuesTitle: 'Our Values',
          values: {
            results: {
              title: 'Commitment to Results',
              description:
                'We focus on achieving tangible and measurable progress for our learners.',
            },
            practice: {
              title: 'Guided Practice',
              description:
                'We believe that real learning happens through structured and purposeful practice.',
            },
            support: {
              title: 'Support & Motivation',
              description:
                'We provide a positive and supportive learning environment that encourages perseverance.',
            },
            clarity: {
              title: 'Clarity & Simplicity',
              description:
                'We offer clear content and an easy-to-understand methodology for all levels.',
            },
            innovation: {
              title: 'Continuous Innovation',
              description:
                'We constantly strive to develop our tools and curricula to provide the best learning experience.',
            },
          },
        },
        story: {
          title: 'Our Story',
          description:
            'Our idea began from a deep conviction that speaking English is not a luxury, but a key to unlocking opportunities in our interconnected world. We noticed that many learners struggle to overcome the fear barrier and start speaking fluently, even after years of studying grammar and vocabulary. From there, our vision emerged to design a methodology that breaks these barriers, focusing intensively on effective daily practice, transforming "I want to speak English" into "I speak English fluently."',
        },
        team: {
          title: 'Our Team',
          description:
            'Our team comprises a group of linguistic experts, experienced teachers, and passionate developers, all committed to one mission: helping you speak fluently. We combine the latest teaching methods, practical experience in language education, and a genuine passion for empowering learners to communicate with confidence.',
        },
        commitment: {
          title:
            'Our Commitment to Quality… Your Effort is the Key to Success!',
          description:
            'We are committed to providing an unparalleled learning experience, built on the latest methods to ensure your mastery of English. Every day, you will find a complete and integrated learning module meticulously designed:',
          features: {
            words: {
              title: 'Selected Daily Words',
              description: 'New words carefully chosen to suit your level.',
            },
            images: {
              title: 'Illustrative Images',
              description:
                "To visually reinforce the word's meaning in your mind.",
            },
            translation: {
              title: 'Accurate Translation',
              description: 'To ensure your complete understanding.',
            },
            sentences: {
              title: 'Sample Sentences',
              description:
                'To see how the word is used in a realistic context.',
            },
            audio: {
              title: 'Audio Files',
              description: 'To hear and repeat the correct pronunciation.',
            },
            recording: {
              title: 'Voice Recording Feature',
              description:
                'To say the word and sentence, and compare your performance with the correct pronunciation.',
            },
            writing: {
              title: 'Writing Practice',
              description:
                'You will practice writing the same words and sentences you have learned to pronounce, hear, and see, to enhance your memory and consolidate the information.',
            },
            grammar: {
              title: 'Daily Grammar Lesson',
              description:
                'Every day, you will learn a simple grammar rule, clearly and easily explained for direct application.',
            },
            idiom: {
              title: 'New Idiom',
              description:
                'Add a common idiom used in daily conversations to your daily vocabulary.',
            },
            phrasal: {
              title: 'New Phrasal Verb',
              description:
                'Learn one new phrasal verb every day to understand English more deeply and speak more fluently.',
            },
            mission: {
              title: 'Your Daily Mission',
              description:
                '11 Steps to Mastery! Every day, 11 interactive tasks await you, ensuring comprehensive and intensive learning.',
            },
          },
          success: {
            title:
              'But most importantly: your mastery of English depends directly on your daily effort and personal commitment. Our website provides you with all the tools and resources, but real progress starts with you:',
            points: {
              perseverance: {
                title: 'Daily Perseverance',
                description:
                  "Dedicate a consistent time each day to study, even if it's short.",
              },
              repetition: {
                title: 'Effective Repetition',
                description:
                  'Pronounce words and sentences over and over. Use the voice recording feature to correct your pronunciation yourself.',
              },
              test: {
                title: 'Daily Test',
                description:
                  "The daily test is the true measure of your progress. Successfully passing it is your condition for moving to the next day's tasks, ensuring you only advance after mastering what you've learned.",
              },
              monitoring: {
                title: 'Close Monitoring',
                description:
                  'Track your progress day by day. You will feel the difference with every word you master and every sentence you speak with confidence.',
              },
            },
          },
        },
        join: {
          title: 'Join Us',
          description:
            'Are you ready to break the language barrier and start speaking fluently? Join us today on your journey to mastering English. Discover the power of daily practice, and see how your communication dreams turn into reality. Your English-speaking future starts here!',
        },
      },
    },
    footer: {
      brand: {
        description:
          'Transform your English skills with our comprehensive learning platform.',
      },
      quickLinks: {
        title: 'Quick Links',
        features: 'Features',
        levels: 'Levels',
        reviews: 'Reviews',
        ourVision: 'Our Vision',
        about: 'About Us',
        contact: 'Contact Us',
      },
      learning: {
        title: 'Learning',
        startLearning: 'Start Learning',
        login: 'Login',
      },
      support: {
        title: 'Support',
        helpCenter: 'Help Center',
        contactUs: 'Contact Us',
        userGuide: 'User Guide',
      },
      legal: {
        title: 'Legal',
        termsAndConditions: 'Terms & Conditions',
        privacyPolicy: 'Privacy Policy',
      },
      copyright: 'All rights reserved.',
      year: '2024',
    },
  },
  TermsAndConditions: {
    title: 'Terms and Conditions',
    lastUpdated: 'Last updated: October 1, 2025',
    sections: {
      acceptance: {
        title: '1. Acceptance of Terms and Service Scope',
        content: {
          scope:
            '1.1 This document ("Terms and Conditions") represents a legal agreement between the user and Englishom.com',
          agreement:
            '1.2 Your use of the website or subscription to any of the services means your complete and unconditional agreement to comply with these terms and conditions, which may be subject to modification at any time.',
          nature:
            '1.3 Nature of Service (Self-Learning): The user acknowledges and agrees that the service provided is an intensive training curriculum that relies entirely on self-learning. The website does not provide human teachers or native speakers or live training sessions. Learning relies on listening to professional recordings and self-comparison through the voice recording feature.',
        },
      },
      intellectualProperty: {
        title: '2. Intellectual Property Rights and Exclusive Use',
        content: {
          ownership:
            '2.1 Ownership: All website content, including texts, short stories, the 1000 basic words, daily sentences, 25-Second challenges, professional audio recordings, tests, images, graphics, and databases, are exclusive intellectual property of Englishom.com',
          prohibition:
            '2.2 Publication Prohibition: It is strictly forbidden to copy, republish, sell, distribute, or share any part of the course content or daily tasks (including audio recordings of lessons) online or offline.',
          personalUse:
            '2.3 Personal Use: The subscription grants you a limited license for personal non-commercial use only. Any violation of these terms will result in immediate account termination.',
        },
      },
      registration: {
        title: '3. Registration, Account, and Payment Terms',
        content: {
          personalAccount:
            '3.1 Personal Account: All registration information must be accurate and correct. The account is personal and cannot be shared; any evidence of account sharing is considered a material breach of these terms and leads to immediate cancellation without refund.',
          pricing:
            '3.2 Pricing and Stability: The subscription price is final and fixed for everyone. The website does not offer any family plans, student discounts, or any other price reductions on advertised prices.',
          paymentMethods:
            '3.3 Payment Methods: All payments are made through secure gateways using Visa and Mastercard only.',
          refundPolicy:
            '3.4 Cancellation and Refund Policy (Final): Completing the purchase represents final approval and unconditional commitment from the user to benefit from the service. Therefore, all subscriptions are non-cancellable and non-refundable after completing the payment process. The user acknowledges their agreement that they have no right to demand compensation or refund from the website.',
        },
      },
      userResponsibility: {
        title: '4. User Responsibility and Audio Content Use',
        content: {
          recordingAccuracy:
            '4.1 Recording Accuracy: The user acknowledges that the quality of training and self-correction depends on the quality and intention of the user in recording their voice and comparing it with audio models.',
          userBehavior:
            '4.2 User Behavior: All audio recordings and shares must be within the scope of respect and not posting any offensive, political, or illegal content.',
          dataAndSecurity:
            '4.3 Data and Security: Personal data and your voice recordings are handled according to our Privacy Policy and are used only to improve your learning experience.',
        },
      },
      disclaimer: {
        title: '5. Disclaimer and Limitations',
        content: {
          disclaimerStatement:
            '5.1 Disclaimer: The service is provided "as is" without any warranties of any kind, express or implied, including, but not limited to, warranties of quality or fitness for a particular purpose.',
          results:
            "5.2 Results: The website does not guarantee achieving specific results, including success in job interviews or any other professional or academic goals, as results depend on the user's seriousness and perseverance.",
          liability:
            "5.3 Liability Limits: In no event shall the website's liability for any losses or damages related to the service exceed the amount paid by the user for the last subscription.",
        },
      },
      termination: {
        title: '6. Account Termination',
        content: {
          terminationRights:
            "6.1 Englishom.com has the right to terminate any user's subscription immediately without prior notice or refund in case of violation of any of these terms, especially clauses related to account sharing or intellectual property rights.",
          accountDeletion:
            '6.2 The user has the right to request deletion of their account and all their data from the website at any time, by contacting the support team.',
        },
      },
    },
    contactInfo: {
      title: 'For inquiries, please contact us at:',
      publishDate: 'Publication date: October 1, 2025',
    },
  },
  PrivacyPolicy: {
    title: 'Privacy Policy',
    intro:
      'This policy explains how we collect, use, and protect the personal information you provide when using our services, especially regarding interactive audio recordings.',
    lastUpdated: 'Last updated: October 1, 2025',
    sections: {
      dataCollection: {
        title: '1. Information We Collect',
        intro:
          'We collect two types of information to provide and improve our services:',
        table: {
          headers: {
            type: 'Information Type',
            examples: 'Examples of Collected Information',
            purpose: 'Purpose of Collection',
          },
          rows: {
            registration: {
              type: 'Registration and Account Information',
              examples: 'Name, email, encrypted password',
              purpose: 'To create your account and provide access to services',
            },
            payment: {
              type: 'Payment Data',
              examples: 'Payment card details (via secure payment gateways)',
              purpose:
                'To process subscriptions and renewals (we do not store your complete card details)',
            },
            performance: {
              type: 'Educational Performance Data',
              examples:
                'Task completion records, daily test results, progress in the 1000 words',
              purpose:
                'To track your progress and ensure curriculum effectiveness',
            },
            audioRecordings: {
              type: 'Exclusive Audio Recordings',
              examples:
                'Your audio files recorded for pronunciation challenges (such as the 25-Second challenge)',
              purpose:
                'Primary purpose: To enable you to compare and self-correct your pronunciation. ',
            },
            usage: {
              type: 'Automatic Usage Data',
              examples:
                'IP address, browser type, pages visited, session timings',
              purpose:
                'To analyze website performance and improve user experience',
            },
          },
        },
      },
      dataUsage: {
        title: '2. How We Use Your Information',
        intro:
          'We use your personal data exclusively for the following purposes:',
        purposes: {
          serviceProvision:
            'To provide and operate the service: Enable you to access daily content and complete tasks.',
          support:
            'Technical support: Respond to your inquiries and resolve technical issues related to your account.',
          payment:
            'Payment management: Process fees and confirm subscriptions.',
          noHumanIntervention:
            'No Human Intervention or Monitoring: The platform confirms that the process of creating, using, and analyzing audio recordings is fully automated. No other party or person (including platform employees) has any right or authority to listen to, monitor, evaluate, or view any audio file from your recordings.',
          exclusiveUse:
            'Exclusive Use for Learners: Audio recordings are used exclusively for the purpose of self-study and training by the learner, as well as to improve the voice recognition feature in the system.',
          ownership:
            'Ownership and Exclusive Access: Audio recordings are the private property of the learner and are stored in their personal file. Only the learner has permission to access them and listen to them for conducting their own performance evaluation.',
          noSharing:
            'No Sharing or Disclosure: In no way are your individual audio recordings shared, sold, or disclosed to any external or internal third party for any marketing, commercial, or administrative purposes.',
        },
        audioCommitment:
          'Our commitment regarding audio recordings: Audio recordings are used only for self-training purposes. We do not share or sell your individual audio recordings to any third party for marketing or commercial purposes.',
      },
      dataProtection: {
        title: '3. Data Protection and Security',
        security:
          'We apply the latest technologies and security procedures to protect your data from unauthorized access, modification, or disclosure.',
        paymentEncryption:
          'All payment data is encrypted using global security protocols when processed through trusted payment gateways.',
        passwordHashing:
          'Passwords are stored using encryption (Hashing), making it impossible for anyone, including our staff, to access your original password.',
      },
      dataSharing: {
        title: '4. Data Sharing with Third Parties',
        intro:
          'We do not sell, trade, or transfer your personal information to external parties except in the following necessary cases:',
        exceptions: {
          serviceProviders:
            'Service Providers: Such as secure payment gateways (Visa/Mastercard) and website hosting services. These parties are obligated to maintain the confidentiality of your data.',
          legalRequirements:
            'Legal Requirements: When required by law or court order.',
        },
      },
      userRights: {
        title: '5. User Rights',
        intro: 'As a user, you have the right to:',
        rights: {
          access:
            'Data Access: Request a copy of the personal data we hold about you.',
          modification:
            'Data Modification: Request correction of any incomplete or inaccurate data.',
          deletion:
            'Right to Deletion: Request deletion of your account and all your personal data permanently from our database, which will be implemented immediately after verification.',
        },
      },
      cookies: {
        title: '6. Cookies',
        description:
          'We use cookies to improve user experience and remember your preferences (such as login) and analyze website usage. You can disable this feature from your browser settings, but this may affect the functionality of some website features.',
      },
    },
  },
  App: {
    dashboard: {
      welcome: 'Welcome back, {{name}}!',
      defaultName: 'Learner',
      subtitle:
        'Continue your English learning journey and track your progress',
      stats: {
        totalProgress: 'Overall Progress',
        levelsCompleted: '{{completed}} of {{total}} levels completed',
        daysCompleted: 'Days Completed',
        daysSubtitle: 'Total learning days',
        unlockedLevels: 'Unlocked Levels',
        levelsSubtitle: 'Available for learning',
        certificates: 'Certificates',
        certificatesSubtitle: 'Earned achievements',
      },
      currentLevel: {
        title: 'Current Level Progress',
        description: 'Continue where you left off',
        dayProgress: 'Day Progress',
        dayCount: 'Day {{current}} of {{total}}',
        continue: 'Continue Learning',
      },
      getStarted: {
        title: 'Ready to Start Learning?',
        description:
          'Choose your level and begin your English learning journey',
        cta: 'Explore Levels',
      },
      quickAccess: {
        title: 'Quick Access',
        description: "Jump directly to today's lessons",
      },
      achievements: {
        title: 'Achievements',
        completed: 'Level completed',
        empty: 'Complete your first level to earn achievements!',
      },
      levels: {
        title: 'Level Overview',
        completed: 'Completed',
        dayProgress: 'Day {{day}}',
        locked: 'Locked',
        viewAll: 'View All Levels',
      },
    },
  },
  Auth: {
    'login-form': {
      title: 'Login to your account',
      description: 'Enter your login credentials to access your account.',
      'login-button': 'Login',
      'forgot-password': 'Forgot password?',
      'no-account': "Don't have an account?",
      'register-link': 'Register now',
      'login-with-facebook': 'Login with Facebook',
      'login-with-google': 'Login with Google',
    },
    'signup-form': {
      title: 'Create a new account',
      description: 'Enter the required information to create your account',
      'first-name-label': 'First Name',
      'first-name-placeholder': 'Mohammed',
      'last-name-label': 'Last Name',
      'last-name-placeholder': 'Salah',
      'signup-button': 'Register Account',
      'has-account': 'Already have an account?',
      'login-link': 'Login now',
      'signup-with-facebook': 'Sign up with Facebook',
      'signup-with-google': 'Sign up with Google',
      'accept-terms': 'By signing up, you agree to our',
    },
    'otp-form': {
      title: 'Verify your email',
      description: 'Enter the 6-digit verification code sent to your email.',
      optSendSuccessfully: 'A verification code has been sent to {{email}}',
      enterCode: 'Enter verification code',
      dontReceiveCode: "Didn't receive the code?",
      resendCode: 'Resend code',
      'verify-button': 'Verify',
      haveNotAccount: "Don't have an account?",
      signUpButton: 'Sign up now',
      label: 'Verification Code',
      invalidOtp: 'Invalid verification code',
    },
    'forget-password-form': {
      emailForm: {
        title: 'Forget Password?',
        description: 'No worries! It happens. Please enter the email.',
      },
      resetPasswordForm: {
        title: 'Reset Your Password',
        description: 'Please enter your new password below.',
        confirmPasswordLabel: 'Confirm Password',
        resetPassword: 'Reset Password',
        passwordDoesNotMatch: 'Passwords do not match',
      },
      otpForm: {
        title: 'Password Reset OTP',
        description: 'We have sent a code to your email {{email}}',
      },
      back: 'Back',
      backToLogin: 'Back to Login',
      continue: 'Continue',
    },
    'or-continue': 'Or you can register with',
  },
  Global: {
    englishom: 'Englishom',
    loading: 'Loading',
    notFound: 'Page Not Found',
    forSixtyDays: '60 days',
    expired: 'Expired',
    completed: 'Completed',
    expiredOn: 'Expired on',
    expiresAt: 'Expires at',
    renew: 'Renew',
    validUntil: 'Valid until',
    renewSubscription: 'Renew Subscription',
    daysLeft: 'Days remaining',
    notFoundDescription: 'The page you are looking for does not exist.',
    lockedLevel: {
      title: 'This level is not available yet',
      description: 'Please purchase this level to gain access.',
      cta: 'Unlock Level',
    },
    congratulations: 'Congratulations!',
    youHaveCompletedDays: "You've completed all 50 days!",
    getCombinedAudio: 'Get Combined Audio',
    generatingAudio: 'Generating combined audio',
    goToHome: 'Go to Home',
    account: 'Account',
    logout: 'Logout',
    startLearning: 'Start Learning',
    unlock: 'Unlock',
    processing: 'Processing...',
    price: 'Price',
    light: 'Light',
    dark: 'Dark',
    comingSoon: 'Coming Soon',
    comingSoonMessage:
      'We are working hard to bring you this lesson. Stay tuned!',
    transcript: 'Transcript',
    second: 'Second',
    seconds: 'Seconds',
    reset: 'Reset',
    writing: {
      title: 'Complete the sentence',
      description: 'Fill in the blank with the correct word',
      checkAnswers: 'Check Answer',
      correct: 'Correct',
      incorrect: 'Incorrect. The correct answers are:',
    },
    todayLesson: {
      instructions: 'Instructions',
      practiceSpeaking: 'Practice Speaking',
      lessonAudio: 'Lesson Audio',
      practiceSentences: 'Practice Sentences',
      recordYourself: 'Record yourself while practicing these sentences',
      recording: 'Recording',
      startRecording: 'Start Recording',
    },
    idioms: {
      definitionCard: {
        title: 'What are Idioms?',
        description: 'Understanding figurative language',
      },
      examplesCard: {
        title: 'Examples',
        description: 'See how the idiom is used in real situations',
        exampleInSituation: 'Example in a situation',
      },
      useCasesCard: {
        title: 'When to use?',
        description: '{{number}} practical applications',
      },
    },
    dayAccessError: {
      title: 'You cannot access Day {{day}} of this level yet',
      description:
        'You cannot access Day {{day}} of this level yet. Please complete the previous lessons to unlock it.',
      goToCurrentDay: 'Go to Current Day',
    },
    'form-fields': {
      'required-error': 'This field is required',
      'min-error': 'This field must be at least {{min}} characters',
      'max-error': 'This field must be at most {{max}} characters',
      email: {
        label: 'Email',
        placeholder: 'Enter your email',
        error: 'Please enter a valid email',
        'required-error': 'Email is required',
        alreadyExists: 'Email already exists',
      },
      password: {
        label: 'Password',
        placeholder: 'Enter your password',
        'min-error': 'Password must be at least {{min}} characters',
        'max-error': 'Password must be at most {{max}} characters',
        'required-error': 'Password is required',
      },
    },
    overallProgress: 'Overall Progress',
    complete: 'Complete',
    'learning-journey-50-days': 'Learning Journey - 50 Days',
    day: 'Day',
    review: 'Review',
    start: 'Start',
    min: 'min',
    totalDays: 'Total Days',
    dailyTime: 'Daily Time',
    progress: 'Progress',
    minPerDay: 'min/Day',
    chooseYourLevel: 'Choose Your Level',
    level: 'Level {{level}}',
    definition: 'Definition',
    definitions: 'Definitions',
    markAsCompleted: 'Mark as Completed',
    markAsUncompleted: 'Mark as Uncompleted',
    show: 'Show',
    hide: 'Hide',
    sidebarItems: {
      home: 'Home',
      levels: 'Levels',
      READ: 'Reading',
      LISTEN: 'Listening',
      WRITE: 'Writing',
      GRAMMAR: 'Grammar',
      PICTURES: 'Pictures',
      TODAY: "Today's Sentences",
      Q_A: 'Q&A',
      SPEAK: 'Speaking',
      DAILY_TEST: 'Daily Test',
      PHRASAL_VERBS: 'Phrasal Verbs',
      IDIOMS: 'Idioms',
    },
    tryAgain: 'Try Again',
    arabic: 'Arabic',
    english: 'English',
    hideExamples: 'Hide Examples',
    showExamples: 'Show Examples',
    vocabulary: 'Vocabulary',
    pictureVocabulary: {
      title: 'Picture Vocabulary',
      description: 'Explore picture vocabulary and learn new words.',
    },
    play: 'Play',
    pause: 'Pause',
    words: 'Words',
    examples: 'Examples',
    useCases: 'Use Cases',
    notes: 'Notes',
    answer: 'Answer',
    next: 'Next',
    prev: 'Previous',
    listenToAudio: 'Listen to Audio',
    clickToPlay: 'Click to Play',
    question: 'Question',
    questionAndAnswer: 'Question & Answer',
    questions: 'Questions',
    showAll: 'Show All',
    showLess: 'Show Less',
    of: 'of',
    phrasalVerb: 'Phrasal Verb',
    yourResults: 'Your results',
    analyzingYourSpeech: 'Analyzing your speech',
    similarity: 'Similarity',
    tip: {
      title: 'Tip',
      description:
        'Listen to the audio carefully and try to match the pronunciation and rhythm you heard.',
    },
    whatYouSaid: 'What you said',
    passed: 'Passed',
    keepPracticing: 'Keep Practicing',
    otherPhrasalVerbs: 'Other Phrasal Verbs',
    back: 'Back',
    certification: 'Certification',
    generating: 'Generating',
    example: 'Example',
    suspendedAccount: {
      title: 'Account Suspended',
      subtitle:
        'Your access to the English Learning Platform has been temporarily suspended',
      suspensionDetails: 'Suspension Details',
      email: 'Email:',
      suspensionDate: 'Suspension Date:',
      endsOn: 'Ends On:',
      reason: 'Reason:',
      timeRemaining: 'Time Remaining',
      timeRemainingDescription:
        'Your account will be automatically reactivated on {{date}}',
      day: 'Day',
      days: 'Days',
      duringSuspension: 'During Suspension',
      cannotAccessMaterials:
        'You cannot access your learning materials or courses',
      progressSafe:
        'Your progress and certificates remain safe and will be restored',
      communityUnavailable:
        'Community features and discussions are temporarily unavailable',
      fullAccessRestored:
        'Full access will be restored automatically after the suspension period',
      appealProcess: 'Appeal Process',
      appealDescription:
        'If you believe this suspension was made in error, you can submit an appeal for early review.',
      appealProvide: 'For appeals, please provide:',
      appealRequirements: {
        accountEmail: 'Your account email address',
        detailedExplanation: 'Detailed explanation of the circumstances',
        supportingEvidence: 'Any supporting evidence or context',
        acknowledgmentGuidelines: 'Acknowledgment of platform guidelines',
      },
      contactSupport: 'Contact Support',
      emailSupport: 'Email Support',
      phoneSupport: 'Phone Support',
      footerMessage:
        'Thank you for your patience. We look forward to welcoming you back to continue your English learning journey.',
      additionalInfo:
        'Suspensions are temporary. Your account and progress will be fully restored after the suspension period ends.',
      phoneNumberCopied: 'Phone number copied to clipboard',
      appealSubject: 'Account Suspension Appeal - {{email}}',
    },
    blockedAccount: {
      title: 'Account Blocked',
      subtitle:
        'Your access to the English Learning Platform has been temporarily restricted',
      accountDetails: 'Account Details',
      email: 'Email:',
      blockDate: 'Block Date:',
      reason: 'Reason:',
      nextSteps: 'Next Steps',
      nextStepsDescription:
        'If you believe this block was made in error or would like to appeal this decision, please contact our support team immediately.',
      contactSupportProvide: 'When contacting support, please include:',
      contactSupportRequirements: {
        accountEmail: 'Your account email address',
        blockNoticeDate: 'The date you noticed the block',
        relevantContext: 'Any relevant context or explanation',
      },
      contactSupport: 'Contact Support',
      emailSupport: 'Email Support',
      phoneSupport: 'Phone Support',
      footerMessage:
        'We appreciate your understanding and look forward to resolving this matter quickly.',
      additionalInfo:
        'For urgent matters, please contact support immediately. Response time is typically within 24 hours.',
      phoneNumberCopied: 'Phone number copied to clipboard',
      appealSubject: 'Account Block Appeal - {{email}}',
    },
    accountOverview: 'Account Overview',
    accountDescription: 'Manage your learning profile and track your progress',
    personalInformation: 'Personal Information',
    completedSuccessfully: 'Completed Successfully',
    verified: 'Verified',
    notVerified: 'Unverified',
    status: 'Status',
    active: 'Active',
    inactive: 'Inactive',
    lastActivity: 'Last Activity',
    memberSince: 'Member Since',
    learningProgress: 'Learning Progress',
    progressDescription: 'Track your progress through levels and daily lessons',
    levelsCompleted: 'Levels Completed',
    daysCompleted: 'Days Completed',
    dailyTest: {
      finish: 'Finish',
      submitAnswer: 'Submit Answer',
      listenToAudio: 'Listen to the audio and choose the correct meaning:',
      lookAtImage: 'Look at the image and choose the correct description:',
      showResults: 'Show Results',
      testCard: {
        title: 'Test Completed!',
        description:
          'You got {{correctAnswers}} out of {{totalQuestions}} questions correct',
        correct: 'Correct',
        inCorrect: 'Incorrect',
        retake: 'Retake test',
        review: 'Review Questions',
        total: 'Total',
      },
    },
    speaking: {
      title: 'Daily Speaking',
      subDescription: 'Practice pronunciation and fluency',
      description:
        'Listen to each sentence, then read it aloud. Try to match the pronunciation and rhythm you heard.',
    },
    errorMessages: {
      microphoneDenied: {
        title: 'Microphone Access Denied',
        message: 'Please allow microphone access to use the recording feature.',
      },
      networkError: {
        title: 'Network Error',
        message: 'Please check your internet connection and try again.',
      },
      badRequest: {
        title: 'Bad Request',
        message:
          'The request was invalid. Please check your input and try again.',
      },
      unauthorized: {
        title: 'Unauthorized',
        message: 'You do not have permission to access this page.',
      },
      forbidden: {
        title: 'Forbidden',
        message: 'You do not have permission to access this page.',
      },
      notFound: {
        title: 'Not Found',
        message: 'The page you are looking for does not exist.',
      },
      timeout: {
        title: 'Timeout',
        message: 'The request took too long. Please try again.',
      },
      tooManyRequests: {
        title: 'Too Many Requests',
        message:
          'You have sent too many requests in a short period of time. Please try again later.',
      },
      internalServerError: {
        title: 'Internal Server Error',
        message:
          'An unexpected error occurred on the server. Please try again later.',
      },
      badGateway: {
        title: 'Bad Gateway',
        message:
          'An error occurred while trying to access the service. Please try again later.',
      },
      unavailableService: {
        title: 'Service Unavailable',
        message:
          'The requested service is currently unavailable. Please try again later.',
      },
      gatewayTimeout: {
        title: 'Gateway Timeout',
        message: 'The server could not get a response in time.',
      },
      unexpectedError: {
        title: 'Unexpected Error',
        message: 'An unexpected error occurred. Please try again later.',
      },
    },
  },
  UserGuide: {
    title: 'Comprehensive User Guide: Your Daily Path to Fluency',
    subtitle:
      'Welcome to the Englishom.com system! You are now part of a unique and intensive training system designed specifically to transform you from a learner to a confident English speaker in record time. There are no traditional teachers; you are your own teacher, and our system is your guide to success.',
    philosophy: {
      title: 'System Philosophy: Why Our Method is the Best?',
      description:
        'We believe that fluency comes from muscle memory and speed of expression, not from memorizing grammar rules.',
      selfLearning: {
        title: 'Self-Learning',
        description:
          'We rely on your self-comparison with professional recordings, which strengthens listening skills and makes you discover your mistakes yourself.',
      },
      challenge: {
        title: '25-Second Challenge',
        description:
          'The goal is not linguistic perfection, but breaking the hesitation barrier and speaking with speed and confidence under pressure.',
      },
      foundation: {
        title: 'Focus on Foundation',
        description:
          'We focus on the most important 1000 words in English (for each level) to ensure building a solid foundation that allows you to speak in 80% of daily situations.',
      },
    },
    gettingStarted: {
      title: 'Starting the Journey: Dashboard and Study Day',
      description:
        'After logging in, you will find the Dashboard - your fluency command center. Our curriculum is built on 10 crucial daily tasks. Your mission is not just to complete them, but to absorb every step in sequence, leading to the mandatory daily test. Passing this test is the only proof of your mastery and the key that unlocks access to the next day.',
      features: {
        dashboard: {
          title: 'Dashboard',
          description:
            'Summary of your progress, number of remaining days in subscription.',
          action: 'Follow tasks in order from top to bottom.',
        },
        words: {
          title: 'Words',
          description: 'Your mastery percentage of essential words.',
          action:
            "Review words you haven't mastered before starting a new day.",
        },
        progress: {
          title: 'Overall Progress',
          description: 'Number of completed levels.',
          action: 'For clarification, where you are now.',
        },
      },
    },
    dailyTasks: {
      title: 'Details of the Ten Daily Tasks (Mandatory Procedures)',
      duration: '~1 hour of focused study',
      description:
        'Every day, you will complete the following ten tasks in about one hour of focus. The order is very important:',
      tip: 'Success Tip',
      tasks: [
        {
          title: 'Daily Text Reading (20 new words)',
          description:
            'Understanding context and practical application of targeted words.',
          tip: 'Read with focus and try to feel the meaning of the complete sentence.',
        },
        {
          title: 'Word Recognition with Images and Audio',
          description:
            'Linking the word to visual and auditory meaning directly.',
          tip: "Don't move on until you're sure you understand each word.",
        },
        {
          title: 'Words in Sentences',
          description: 'Hearing words within a complete sentence.',
          tip: 'Not just an educational step, but a qualitative leap.',
        },
        {
          title: 'Writing',
          description:
            'Writing plays a crucial and indirect role in enhancing fluency.',
          tip: 'Writing transforms words you hear and read into active practice.',
        },
        {
          title: 'Recording Pronunciation and Comparison',
          description:
            'Building muscle memory for correct pronunciation and improving clarity.',
          tip: 'Important: Listen to the professional recording then record your voice and compare it accurately.',
        },
        {
          title: '25-Second Challenge (6 daily sentences)',
          description:
            'The cornerstone: Overcoming hesitation and achieving speed in expression.',
          tip: 'Repeat sentences repeatedly until you memorize them well, then record them within 20 seconds!',
        },
        {
          title: 'Questions and Answers (7 questions)',
          description: 'Advance preparation for daily conversation scenarios.',
          tip: 'Read the question and answer it aloud as if someone is asking you.',
        },
        {
          title: 'Simple Grammar Rule',
          description: 'Clarifying simple basic rules in sentence context.',
          tip: 'Focus on practical examples rather than memorizing theoretical explanation.',
        },
        {
          title: 'Phrasal Verbs',
          description: 'Mastering common expressions used daily.',
          tip: 'Try to use the new phrasal verb in your own sentence immediately.',
        },
        {
          title: 'Idioms',
          description:
            'Mastering the spirit of the language and speaking cleverly like a native speaker.',
          tip: 'Memorize the sentence containing the expression and use it in your daily conversations.',
        },
        {
          title: 'Final Daily Test',
          description:
            "Measuring your comprehension and understanding of 100% of the day's content.",
          tip: 'Mandatory: You must pass the test successfully before the next study day opens.',
        },
      ],
    },
    quickFaq: {
      title: 'Quick Questions About Features',
      questions: [
        {
          question: 'Why do I record my voice?',
          answer:
            'To develop "muscle memory" for pronunciation and self-correct, which breaks the fear and hesitation barrier.',
        },
        {
          question: 'What happens after 50 days?',
          answer:
            'You will have completed training on the most important 1000 words, and you will be able to express yourself fluently and without stopping for a full 15 minutes!',
        },
        {
          question: 'Must I complete all tasks?',
          answer:
            'Yes, our system is built on daily accumulation. You cannot move to the next day without completing all tasks.',
        },
        {
          question: 'Are there recommended external resources?',
          answer:
            'No, we focus on our comprehensive system to protect you from distraction. Our system is designed to be sufficient and complete.',
        },
      ],
    },
    success: {
      title: 'Start Now, Your Fluency Awaits You!',
      description:
        'In case you encounter any technical problems, please contact the support team.',
      cta: 'Begin Your Journey',
    },
    support: {
      note: 'Important Note: If you encounter any technical problems, please contact the support team via support@englishom.com.',
    },
  },
  ShareProgress: {
    title: 'My Learning Progress',
    subtitle: 'I am learning English with Englishom!',
    currentProgress: 'Current Progress',
    remainingDuration: 'Remaining Duration',
    daysToComplete: 'days to complete the course',
    days: 'Days',
    completed: 'Completed',
    cta: 'Join me to a wide world and learn English with Englishom',
    startLearning: 'Start Learning',
    ofDays: 'Of {{totalDays}} days',
    student: 'Student',
    currentLevel: 'Current Level',
    englishomStudent: 'Englishom Student',
  },
} satisfies TranslationType;
