/// <reference types="vitest" />
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import path from 'path';
import { tanstackRouter } from '@tanstack/router-plugin/vite';

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    tanstackRouter({
      target: 'react',
      autoCodeSplitting: true,
    }),
    react(),
    tailwindcss(),
  ],
  test: {
    globals: true,
    environment: 'jsdom',
    setupFiles: './setupTests.ts',
    reporters: ['default', 'tap-flat'],
  },
  resolve: {
    alias: {
      '@modules': path.resolve(__dirname, './src/modules'),
      '@ui': path.resolve(__dirname, './src/shared/components/ui'),
      '@lib': path.resolve(__dirname, './src/shared/lib'),
      '@components': path.resolve(__dirname, './src/shared/components'),
      '@hooks': path.resolve(__dirname, './src/shared/hooks'),
      '@shared': path.resolve(__dirname, './src/shared'),
      '@': path.resolve(__dirname, './src'),
    },
  },
  build: {
    target: 'esnext',
    minify: 'esbuild',
    rollupOptions: {
      output: {
        manualChunks: {
          // Core React bundle - most frequently used
          'vendor-react': ['react', 'react-dom'],

          // UI components - group related UI libraries
          'vendor-ui': [
            '@radix-ui/react-avatar',
            '@radix-ui/react-collapsible',
            '@radix-ui/react-dialog',
            '@radix-ui/react-direction',
            '@radix-ui/react-dropdown-menu',
            '@radix-ui/react-label',
            '@radix-ui/react-progress',
            '@radix-ui/react-separator',
            '@radix-ui/react-slot',
            '@radix-ui/react-tooltip',
            'input-otp',
            'lucide-react',
            'sonner',
          ],

          // Styling utilities - lightweight, group together
          'vendor-styles': [
            'clsx',
            'class-variance-authority',
            'tailwind-merge',
          ],

          // Form handling - frequently used together
          'vendor-forms': ['react-hook-form', '@hookform/resolvers', 'zod'],

          // Tanstack ecosystem - used together
          'vendor-tanstack': [
            '@tanstack/react-router',
            '@tanstack/react-query',
          ],

          // Internationalization
          'vendor-i18n': ['i18next', 'react-i18next'],

          // State management
          'vendor-state': ['zustand'],

          // Data fetching and utilities
          'vendor-utils': ['axios', 'dompurify'],
        },
        // Optimize file names for better caching
        chunkFileNames: 'js/[name]-[hash].js',
        assetFileNames: 'assets/[name]-[hash][extname]',
      },
    },
    // Improve build performance
    chunkSizeWarningLimit: 1000,
    sourcemap: false, // Disable in production for smaller builds
  },
});
