export enum QuestionType {
  text = 'text',
  audio = 'audio',
  image = 'image',
}
