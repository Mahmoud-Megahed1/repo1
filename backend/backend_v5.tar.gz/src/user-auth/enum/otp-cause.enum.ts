export enum OtpCause {
  EMAIL_VERIFICATION = 'email_verification',
  FORGET_PASSWORD = 'forget_password',
}
