
export enum TokenType {

    PASSWORD_RESET = 'password_reset',
    ACCESS_TOKEN  = 'access_token',
}